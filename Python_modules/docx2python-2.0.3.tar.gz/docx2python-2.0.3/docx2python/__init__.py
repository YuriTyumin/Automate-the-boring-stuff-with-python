from .main import docx2python  # noqa: 401

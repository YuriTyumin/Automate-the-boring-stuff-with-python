default_result_dir_name = 'done'
output_result_file_name = 'report.xlsx'
output_report_file_name = 'report.txt'

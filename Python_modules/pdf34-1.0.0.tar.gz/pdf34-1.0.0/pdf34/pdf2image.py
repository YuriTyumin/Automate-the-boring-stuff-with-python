def getPdf(path):
    print("pdf path", path)
